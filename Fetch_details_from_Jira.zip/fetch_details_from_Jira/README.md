## Jira Integration API
A FastAPI-based application for interacting with Jira to manage boards, epics, stories, tasks, and issues, including creating issues, fetching hierarchical data, and closing tasks.
Table of Contents

## Overview
This project provides a RESTful API for interacting with Jira to manage project workflows. It allows users to create issues, fetch board-epic-story-task hierarchies, manage comments and attachments, and close tasks. The API is built using FastAPI, integrates with Jira's REST API, and supports file uploads for issue attachments.

## Features

Issue Creation: Create Jira issues with summaries, descriptions, links, and image attachments.
Hierarchy Retrieval: Fetch complete board-epic-story-task hierarchies for a project, including standalone issues.
Task Management: Close tasks with optional comments and retrieve task details, including subtasks.
Comment Management: Add and list comments on issues.
Attachment Management: Upload and list attachments for issues.
Project Team Insights: Retrieve user roles for a specified project.
Data Export: Save hierarchical data to JSON files for analysis.

## Installation

Install dependencies:
pip install -r requirements.txt


Set up environment variables (see Configuration).

Run the application:
uvicorn main:app --reload



## Configuration
Create a .env file in the project root with the following variables:
JIRA_DOMAIN=your-jira-domain.atlassian.net
JIRA_EMAIL=your-email@example.com
JIRA_API_TOKEN=your-jira-api-token


JIRA_DOMAIN: Your Jira instance domain (e.g., yourcompany.atlassian.net).
JIRA_EMAIL: Your Jira account email.
JIRA_API_TOKEN: API token from Jira (generate at https://id.atlassian.com/manage-profile/security/api-tokens).

## Usage

Start the FastAPI server:
uvicorn main:app --host 0.0.0.0 --port 8000


Access the interactive API documentation at http://localhost:8000/docs.

Use the API endpoints to create issues, fetch hierarchical data, manage comments and attachments, or close tasks.


## API Endpoints

POST /create_issue: Create a Jira issue with a summary, description, optional link, and image attachment.
GET /boards: Fetch all Jira boards.
GET /boards/{board_id}/epics: Fetch epics for a specific board with metadata (description, comments, attachments).
GET /epics/{epic_key}/stories: Fetch stories and metadata for a specific epic.
GET /stories/{story_key}/tasks: Fetch tasks and subtasks linked to a story.
GET /teams/project: Retrieve users and their roles for a project.
GET /hierarchy: Fetch the full board-epic-story-task hierarchy.
GET /hierarchy/save: Save the hierarchy to jira_hierarchy.json.
GET /hierarchy_issue: Fetch the hierarchy with all issues for a project.
GET /hierarchy_issue/save: Save the issue hierarchy to jira_hierarchy_issue.json.
GET /issues/{issue_key}: Get details of a specific issue.
PUT /issues/{issue_key}: Update an issue's summary.
DELETE /issues/{issue_id}: Delete an issue.
GET /issues/{issue_key}/description: Get an issue's description.
PUT /issues/{issue_key}/description: Update an issue's description.
GET /issues/{issue_key}/comments: List comments on an issue.
POST /issues/{issue_key}/comments: Add a comment to an issue.
GET /issues/{issue_key}/attachments: List attachments for an issue.
POST /issues/{issue_key}/attachments: Upload an attachment to an issue.
DELETE /jira/api/{task_id}/closing_ticket: Close a task with an optional comment.

Directory Structure
jira-integration-api/
├── main.py              # Main FastAPI application
├── requirements.txt     # Python dependencies
├── README.md            # Project documentation
├── .env                 # Environment variables (not tracked)
├── jira_hierarchy.json  # Saved hierarchy data (optional)
├── jira_hierarchy_issue.json  # Saved issue hierarchy data (optional)

## Dependencies
Listed in requirements.txt. Key dependencies include:

fastapi: For building the RESTful API.
uvicorn: ASGI server for running the FastAPI app.
pydantic: For data validation and modeling.
requests: For making HTTP requests to the Jira API.
python-dotenv: For loading environment variables.
python-multipart: For handling file uploads.

## Contributing

Fork the repository.
Create a new branch (git checkout -b feature/your-feature).
Make your changes and commit (git commit -m "Add your feature").
Push to the branch (git push origin feature/your-feature).
Open a pull request.

## License
This project is licensed under the MIT License.